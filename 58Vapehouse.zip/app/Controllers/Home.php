<?php

namespace App\Controllers;

use App\Models\BundledetailModel;
use App\Models\BundleModel;
use App\Models\CategoryModel;
use App\Models\CashModel;
use App\Models\DebtModel;
use App\Models\GconfigModel;
use App\Models\OutletModel;
use App\Models\UserModel;
use App\Models\MemberModel;
use App\Models\PaymentModel;
use App\Models\ProductModel;
use App\Models\StockModel;
use App\Models\VariantModel;
use App\Models\TransactionModel;
use App\Models\TrxdetailModel;
use App\Models\TrxpaymentModel;
use App\Models\TrxotherModel;
use App\Models\BookingModel;
use App\Models\BookingdetailModel;
use App\Models\PurchaseModel;
use App\Models\PurchasedetailModel;
use App\Models\PresenceModel;
use App\Models\GroupUserModel;
use App\Models\OldStockModel;
use Myth\Auth\Models\GroupModel;

class Home extends BaseController
{
    public function index()
    {
        // Calling models
        $db                 = \Config\Database::connect();
        $TransactionModel   = new TransactionModel();
        $TrxdetailModel     = new TrxdetailModel();
        $TrxpaymentModel    = new TrxpaymentModel();
        $TrxotherModel      = new TrxotherModel();
        $PaymentModel       = new PaymentModel();
        $ProductModel       = new ProductModel();
        $VariantModel       = new VariantModel();
        $StockModel         = new StockModel();
        $BundleModel        = new BundleModel();
        $BundledetailModel  = new BundledetailModel();
        $DebtModel          = new DebtModel();
        $MemberModel        = new MemberModel();
        $PurchaseModel      = new PurchaseModel();
        $PurchasedetModel   = new PurchasedetailModel();

        // Populating Data
        $input          = $this->request->getGet('daterange');
        // $trxdetails     = $TrxdetailModel->findAll();
        // $trxpayments    = $TrxpaymentModel->findAll();
        $products       = $ProductModel->findAll();
        $variants       = $VariantModel->findAll();
        // $debts          = $DebtModel->findAll();
        // $customers      = $MemberModel->findAll();
        $bundles        = $BundleModel->findAll();
        $bundets        = $BundledetailModel->findAll();
        $purchasedet    = $PurchasedetModel->findAll();
        $payments       = $PaymentModel->findAll();

        // Populating Data
        if (!empty($input)) {
            $daterange  = explode(' - ', $input);
            $startdate  = $daterange[0];
            $enddate    = $daterange[1];
        } else {
            $startdate  = date('Y-m-1');
            $enddate    = date('Y-m-t');
        }

        $firstday       = date('Y-m-1');
        $lastday        = date('Y-m-t');
        $today          = date('Y-m-d');
        $month          = date('Y-m-t');

        if ($this->data['outletPick'] === null) {
            if ($startdate === $enddate) {
                $transactions   = $TransactionModel->where('date >=', $startdate.' 00:00:00')->where('date <=', $enddate.' 23:59:59')->find();
                $trxothers      = $TrxotherModel->notLike('description', 'Top Up')->notLike('description', 'Debt')->where('date >=', $startdate.' 00:00:00')->where('date <=', $enddate.' 23:59:59')->find();
            } else {
                $transactions   = $TransactionModel->where('date >=', $startdate)->where('date <=', $enddate)->find();
                $trxothers      = $TrxotherModel->notLike('description', 'Top Up')->notLike('description', 'Debt')->where('date >=', $startdate)->where('date <=', $enddate)->find();
            }

            $trxmonths      = $TransactionModel->where('date >=', $firstday.' 00:00:00')->where('date <=', $lastday.' 23:59:59')->find();
            $todayexpenses  = $TrxotherModel->notLike('description', 'Top Up')->notLike('description', 'Debt')->where('date >=', $today.' 00:00:00')->where('date <=', $today.' 23:59:59')->find();
            $trxtodays      = $TransactionModel->where('date >=', $today.' 00:00:00')->where('date <=', $today.' 23:59:59')->find();
            $stocks         = $StockModel->where('restock !=', '0000-00-00 00:00:00')->where('sale !=', '0000-00-00 00:00:00')->findAll();
        } else {
            if ($startdate === $enddate) {
                $transactions   = $TransactionModel->where('date >=', $startdate.' 00:00:00')->where('date <=', $enddate.' 23:59:59')->where('outletid', $this->data['outletPick'])->find();
                $trxothers      = $TrxotherModel->notLike('description', 'Top Up')->notLike('description', 'Debt')->where('date >=', $startdate.' 00:00:00')->where('date <=', $enddate.' 23:59:59')->where('outletid', $this->data['outletPick'])->find();
            } else {
                $transactions   = $TransactionModel->where('date >=', $startdate)->where('date <=', $enddate)->where('outletid', $this->data['outletPick'])->find();
                $trxothers      = $TrxotherModel->notLike('description', 'Top Up')->notLike('description', 'Debt')->where('date >=', $startdate)->where('date <=', $enddate)->where('outletid', $this->data['outletPick'])->find();
            }

            $trxmonths      = $TransactionModel->where('date >=', $firstday.' 00:00:00')->where('date <=', $lastday.' 23:59:59')->where('outletid', $this->data['outletPick'])->find();
            $todayexpenses  = $TrxotherModel->notLike('description', 'Top Up')->notLike('description', 'Debt')->where('date >=', $today.' 00:00:00')->where('date <=', $today.' 23:59:59')->where('outletid', $this->data['outletPick'])->find();
            $trxtodays      = $TransactionModel->where('date >=', $today.' 00:00:00')->where('date <=', $today.' 23:59:59')->where('outletid', $this->data['outletPick'])->find();
            $stocks         = $StockModel->where('restock !=', '0000-00-00 00:00:00')->where('sale !=', '0000-00-00 00:00:00')->where('outletid', $this->data['outletPick'])->find();
        }

        // Stock Cycle
        $stok           = array_slice($stocks, 0, 3);
        array_multisort(array_column($stok, 'restock'), SORT_DESC, $stok);

        // Transaction Data
        $transactiondata    = array();
        $discount           = array();
        $debtvalue          = array();
        $downpayment        = array();
        $totalmember        = array();
        $trxvalue           = array();
        $pointused          = array();
        $marginmodal        = array();
        $bestproduct        = array();
        $productsale        = array();
        $bestpayment        = array();
        $saly               = array();
        $hour               = array();

        foreach ($transactions as $transaction) {
            // Transaction Value Array
            $trxvalue[]         = (Int)$transaction['value'];

            // Transaction Point Used Array
            $pointused[]        = $transaction['pointused'];

            // Discount Transaction
            if (!empty($transaction['discvalue'])) {
                if ($transaction['disctype'] == "0") {
                    $discount[]  = $transaction['discvalue'];
                } else {
                    $discount[]  = (int)$transaction['value'] * ((int)$transaction['discvalue'] / 100);
                }
            }

            // Finding Data
            $debtsdata          = $DebtModel->where('transactionid', $transaction['id'])->find();
            $trxdetailsdata     = $TrxdetailModel->where('transactionid', $transaction['id'])->find();
            $trxpaymentsdata    = $TrxpaymentModel->where('transactionid', $transaction['id'])->where('paymentid !=', '0')->find();

            // Debt Total $ Total Debt Customer & Down Payment
            foreach ($debtsdata as $debt) {
                // Debt Value
                $debtvalue[]        = $debt['value'];

                // Down Payment
                if ($transaction['amountpaid'] != 0) {
                    $downpayment[]  = $transaction['amountpaid'];
                }

                // Debt Member
                $totalmember[]      = $MemberModel->find($debt['memberid']);
            }

            // Trxdetail Array
            foreach ($trxdetailsdata as $trxdet) {
                // Transaction Detail Margin Modal
                $marginmodal[]      = (Int)$trxdet['marginmodal'] * (Int)$trxdet['qty'];
    
                // Transaction Detail Discount Variant
                if ($trxdet['discvar'] != 0) {
                    $discount[]     = $trxdet['discvar'];
                }

                // Data Variant
                $variantsdata       = $VariantModel->find($trxdet['variantid']);

                if (!empty($variantsdata)) {
                    $varid          = $variantsdata['id'];
                    $varname        = $variantsdata['name'];
                    $productsdata   = $ProductModel->find($variantsdata['productid']);

                    if (!empty($productsdata)) {
                        $prodname   = $productsdata['name'];
                    } else {
                        $prodname   = '';
                    }
                } else {
                    $varname        = '';
                    $varid          = '';
                    $productsdata   = '';
                    $prodname       = '';
                }

                // Data Bundle
                $bundlesdata    = $BundleModel->find($trxdet['bundleid']);

                if (!empty($bundlesdata)) {
                    $bundleid       = $bundlesdata['id'];
                    $bundlename     = $bundlesdata['name'];
                } else {
                    $bundleid       = '';
                    $bundlename     = '';
                }

                // Best Selling Product
                if ($trxdet['variantid'] != 0) {
                    $bestid     = $varid;
                    $name       = $prodname.' - '.$varname;
                } else {
                    $bestid     = $bundleid;
                    $name       = $bundlename;
                }

                // Product Data For Best Selling
                $bestproduct[]    = [
                    'id'        => $bestid,
                    'name'      => $name,
                    'qty'       => $trxdet['qty'],
                ];
            }
    
            // Products Sales
            $productsale[]      = $trxdet['qty'];
    
            foreach ($trxpaymentsdata as $trxpay) {
                $payments           = $PaymentModel->find($trxpay['paymentid']);
                $bestpayment[] = [
                    'id'    => $payments['id'],
                    'name'  => $payments['name'],
                    'value' => $trxpay['value'],
                ];
            }
            
            // Bussy Day
            $datesale   = date_create($transaction['date']);
            $saledate   = $datesale->format('Y-m-d');
            $hoursale   = $datesale->format('H');
            $hour[]     = date('H', strtotime($transaction['date']));
            $saly[]     = [
                'date'  => $saledate,
                'value' => $transaction['value'],
                'hours' => $hoursale,
                'trx'   => '1',
            ];
        }

        // Total Transaction
        $transactiondata['totaltrx']        = count($transactions);

        // Total Transaction Value
        $transactiondata['totaltrxvalue']   = array_sum($trxvalue);

        // Total Point Used
        $transactiondata['totalpointused']  = array_sum($pointused);

        // Total Discount
        $transactiondata['totaldiscount']   = array_sum($discount);

        // Total Gross
        $transactiondata['gross']           = (Int)$transactiondata['totaltrxvalue'] + (Int)$transactiondata['totalpointused'] + (Int)$transactiondata['totaldiscount'];

        // Total Profit
        $transactiondata['profit']          = array_sum($marginmodal);

        // Total Debt Value
        $transactiondata['debtvalue']       = array_sum($debtvalue);

        // Total Down Payment
        $transactiondata['dp']              = array_sum($downpayment);

        // Total Member Debt
        $transactiondata['debtmember']      = count($totalmember);

        // Total Product Sale
        $transactiondata['productsale']     = array_sum($productsale);

        // Top 3 Product Sell
        $bestseller = [];
        foreach ($bestproduct as $product) {
            if (!isset($bestseller[$product['id']])) {
                $bestseller[$product['id']] = $product;
            } else {
                $bestseller[$product['id']]['qty'] += $product['qty'];
            }
        }
        array_multisort(array_column($bestseller, 'qty'), SORT_DESC, $bestseller);
        $transactiondata['bestsell'] = array_slice($bestseller, 0, 3);

        // Top 3 Payment Method
        $bestpay = [];
        foreach ($bestpayment as $paymet) {
            if (!isset($bestpay[$paymet['id']])) {
                $bestpay[$paymet['id']] = $paymet;
            } else {
                $bestpay[$paymet['id']]['value'] += $paymet['value'];
            }
        }
        array_multisort(array_column($bestpay, 'value'), SORT_DESC, $bestpay);
        $transactiondata['bestpayment'] = array_slice($bestpay, 0, 3);

        // Cashin Cash Out
        $cashin     = [];
        $cashout    = [];
        foreach ($trxothers as $trxother) {
            if ($trxother['type'] === "0") {
                $cashin[] = $trxother['qty'];
            } else {
                $cashout[] = $trxother['qty'];
            }
        }

        $transactiondata['cashin']  = array_sum($cashin);
        $transactiondata['cashout'] = array_sum($cashout);

        // Today's Expenses
        $todayexp = array();
        foreach ($todayexpenses as $todexp) {
            if ($todexp['type'] === "1") {
                $todayexp[] = $todexp['qty'];
            }
        }
        $transactiondata['todayexp']    = array_sum($todayexp);

        // Today's Sales
        $trxtoday = array();
        foreach ($trxtodays as $trxtod) {
            $trxtoday[] = $trxtod['value'];
        }
        $transactiondata['todaytrx']    = array_sum($trxtoday);

        // Month's Sales
        $thismonth = [];
        foreach ($trxmonths as $trxmonth) {
            $thismonth[] = (int)$trxmonth['value'];
        }
        $transactiondata['monthtrx']    = array_sum($thismonth);

        // Average transaction
        $salesresult = array_sum($trxvalue);

        if ($salesresult !== 0) {
            $salestrx                   = count($transactions);
            $averagedays                = $salesresult / $salestrx;
            $sale                       = sprintf("%.2f", $averagedays);
            $doblesale                  = ceil($sale);
            $saleaverage                = sprintf("%.2f", $doblesale);
        } else {
            $averagedays                = "0";
            $sale                       = sprintf("%.2f", $averagedays);
            $doblesale                  = ceil($sale);
            $saleaverage                = sprintf("%.2f", $doblesale);
        }
        $transactiondata['saleaverage'] = $saleaverage;

        // Average per days
        $now                            = date_create($startdate);
        $your_date                      = date_create($enddate)->modify('+1 day');
        $datediff                       = date_diff($now, $your_date);
        $days                           = $datediff->format("%a");
        $dateaverage                    = ceil($salesresult / (int)$days);
        $resultaveragedays              = sprintf("%.2f", $dateaverage);
        $transactiondata['averagedays'] = $resultaveragedays;

        // Bussy Days
        $busies = array_count_values($hour);
        arsort($busies);
        $busyhours = array_slice(array_keys($busies), 0, 1, true);
        if (!empty($busyhours)) {
            $bussytime = $busyhours[0] . ':00';
        } else {
            $bussytime = "00:00";
        }
        $transactiondata['bussytime'] = $bussytime;

        $saledet = [];
        foreach ($saly as $sels) {
            if (!isset($saledet[$sels['date']])) {
                $saledet[$sels['date']] = $sels;
            } else {
                $saledet[$sels['date']]['value'] += $sels['value'];
                $saledet[$sels['date']]['trx'] += $sels['trx'];
            }
        }
        $saledet = array_values($saledet);

        array_multisort(array_column($saledet, 'trx'), SORT_DESC, $saledet);
        $daysale        = array_slice($saledet, 0, 1);
        $bussyday       = 0;
        foreach ($daysale as $days) {
            $datesale   = date_create($days['date']);
            $bussyday   = $datesale->format('l');
        }
        $transactiondata['bussyday'] = $bussyday;

        // Parsing Data To View
        $data                       = $this->data;
        $data['title']              = lang('Global.dashboard');
        $data['description']        = lang('Global.dashdesc');
        $data['transactiondata']    = $transactiondata;
        // $data['sales']           = $summary;
        // $data['profit']          = $keuntunganmodal;
        $data['products']           = $products;
        $data['variants']           = $variants;
        $data['bundles']            = $bundles;
        $data['bundets']            = $bundets;
        // $data['trxamount']       = $trxamount;
        // $data['qtytrxsum']       = $qtytrxsum;
        // $data['pointusedsum']    = $pointusedsum;
        // $data['gross']           = $gross;
        // $data['cashinsum']       = $cashinsum;
        // $data['cashoutsum']      = $cashoutsum;
        // $data['top3prod']        = $best3;
        // $data['top3paymet']      = $bestpay3;
        $data['stocks']             = $stok;
        // $data['average']         = (int)$saleaverage;
        $data['startdate']          = strtotime($startdate);
        $data['enddate']            = strtotime($enddate);
        // $data['trxdebtval']      = array_sum($trxdebtval);
        // $data['averagedays']     = $resultaveragedays;
        // $data['bussyday']        = $day;
        // $data['bussytime']       = $busy;
        // $data['todayexps']       = $todayexps;
        $data['month']              = $month;
        // $data['sumtrxtoday']     = $sumtrxtoday;

        // if ($this->data['outletPick'] != null) {
        //     $data['payments']       = $PaymentModel->where('outletid', $this->data['outletPick'])->find();
        // } else {
            $data['payments']       = $payments;
        // }

        return view('dashboard', $data);
    }

    public function outletses($id)
    {
        $session = \Config\Services::session();

        if ($id === '0') {
            $session->remove('outlet');
        } else {
            if ($session->get('outlet') != null) {
                $session->remove('outlet');
            }
            $session->set('outlet', $id);
        }

        return redirect()->to('');
    }

    public function ownership()
    {
        $authorize = service('authorization');

        $authorize->removeUserFromGroup(3, 1);

        $authorize->addUserToGroup(3, 'operator');
    }

    public function trial()
    {
        $VariantModel   = new VariantModel;
        $OldStockModel = new OldStockModel;

        $variants = $VariantModel->findAll();

        foreach ($variants as $variant) {
            if ($variant['id'] != "2358") {
                // $variantdata = [
                //     'id'        => $variant['id'],
                //     'hargadasar' => $variant['hargamodal'],
                //     'hargarekomendasi' => (Int)$variant['hargamodal'] + (Int)$variant['hargajual'],
                // ];
                // $VariantModel->save($variantdata);

                $data = [
                    'variantid' => $variant['id'],
                    'hargadasar' => $variant['hargamodal'],
                    'hargamodal' => $variant['hargamodal'],
                ];
                $OldStockModel->insert($data);
            }
        }
    }

    public function phpinfo()
    {
        phpinfo();
    }
}
